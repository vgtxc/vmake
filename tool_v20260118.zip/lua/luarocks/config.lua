-- lastEdit=>2025.12.24-17:15
-- creat:2025.12.24
-- 指定配置文件路径
-- 添加环境变量: luarocks_config = luarocks_config.lua

-- lua根路径
lua_root = "C:\\sftw\\tool\\devTool\\lua\\v5.4.2"
-- lua解释器
lua_excu = lua_root .. "\\lua_excu"
-- luarocks路径
luarocks_root = lua_root .. "\\luarocks"

-- 默认安装树
rocks_trees = {
   {
      name = "vgt",
      root = luarocks_root,
   },
}

variables = {
    -- 指定编译器命令
    CC = "gcc",
    CXX = "g++",
    -- 指定链接器标志 (告诉链接器使用 MinGW 风格)
    LINKFLAGS = "-shared",

    -- 指定lua路径
    LUA = lua_excu.."\\lua54.exe",
    -- luarocks安装配置
    LUA_BINDIR = lua_excu.."\\bin",
    LUA_INCDIR = lua_excu.."\\include",
    LUA_LIBDIR = lua_excu.."\\lib",
}